# StratDesk Pro — Institutional Command Center & Execution Terminal

> Premium, self-hosted bidirectional command center, emergency kill-switch, and forensic trade ledger for algorithmic trading systems.

Welcome to **StratDesk Pro**. Your purchase includes 100% source code access to institutional command-and-control capabilities:
- **Bidirectional HMAC Command Bus**: Emergency Kill-Switch (`FLATTEN & HALT`), runtime strategy pause switches, and parameter reloader.
- **Forensic Audit Trade Ledger**: R-multiple tracking, slippage analysis, Sharpe ratio, screenshot mode with cryptographic watermark, CSV export.
- **Automated Trade Ingestion**: Pre-wired `POST /api/ledger` server route ready to consume executions.
- **Python CCXT Adapter**: `scripts/bot_adapter.py` ready to integrate into your live bot.
- **All 20 Architectures Unlocked**: Full access to all specialized topologies.
- **6 Precision Themes**: `terminal`, `obsidian`, `quant`, `command`, `vector`, `light`.

---

## ⚡ Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start the command center
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 🐍 Testing Bot Ingestion (Python)

StratDesk Pro includes an asynchronous Python adapter in `scripts/bot_adapter.py`:

```bash
# Run the demo adapter pipeline to push an audited trade to your local dashboard:
python scripts/bot_adapter.py
```

You will see:
```text
[1] Prepared Audited Trade Payload...
[2] Transmitting execution to StratDesk Command Bus (http://localhost:3000/api/ledger)...
[STRATDESK INGESTION SUCCESS] HTTP 201 — Recorded ID: TRD-2026-0907-143
[3] Ingestion Confirmed by StratDesk Pro: Trade verified on dashboard.
```

Switch to the **Audit Ledger** tab (or visit `/ledger`) to inspect your freshly recorded trade with full forensic metrics!

---

## 🛡️ Bidirectional HMAC Command Verification

Dispatched actions (emergency halt, strategy reload) require HMAC-SHA256 signature verification in your bot:

```python
import hmac
import hashlib

def verify_stratdesk_command(payload_bytes: bytes, signature: str, secret_key: str) -> bool:
    computed = hmac.new(secret_key.encode(), payload_bytes, hashlib.sha256).hexdigest()
    return hmac.compare_digest(computed, signature)
```

---

## 🤖 Universal AI Integration & Auto-Moulding

StratDesk Pro is engineered with native rules for **every major AI coding assistant**:
- **Cursor IDE**: Pre-loaded `.cursorrules`
- **Claude Code (Anthropic)**: Pre-loaded `CLAUDE.md`
- **Windsurf (Cascade)**: Pre-loaded `.windsurfrules`
- **GitHub Copilot & Codex**: Pre-loaded `.github/copilot-instructions.md`
- **Google Antigravity & Gemini**: Pre-loaded `.antigravity/rules.md`
- **Aider & Open Code**: Pre-loaded `CONVENTIONS.md`
- **Universal Specification**: `STRATDESK_SPEC.md` & `AI_RULES.md`

Simply open your extracted StratDesk Pro project in any AI editor alongside your bot and prompt:
> *"Connect this dashboard to my trading bot."*

The AI assistant will automatically read the embedded directives, preserve the institutional dark HUD terminal layout, mould the 6 metric cards and parameters to your specific bot, and generate a non-invasive bridge adapter.

---

## 🔒 Security & Data Privacy

- **100% Client-Side**: No cloud servers ever receive your trading orders, positions, or keys.
- **Zero Credentials Required**: StratDesk never handles your private exchange API keys.
- Support: `stratdesk.pro@gmail.com`
