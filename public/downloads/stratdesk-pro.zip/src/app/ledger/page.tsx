import React from "react";
import { Metadata } from "next";
import { TradeLedger } from "@/components/ledger/TradeLedger";

export const metadata: Metadata = {
  title: "Audit Trade Ledger // StratDesk Pro",
  description: "Audited institutional execution journal, R-multiple metrics, and forensic telemetry records.",
};

export default function LedgerPage() {
  return (
    <div className="pt-24 pb-16 px-3 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
      <TradeLedger />
    </div>
  );
}
