"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Logo } from "@/components/ui/Logo";
import { cn } from "@/lib/utils";
import { Menu, X, Terminal, Compass, BookOpen, HelpCircle, FileText, Sliders } from "lucide-react";

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [pathname]);

  const navLinks = [
    { label: "Command Center", href: "/", icon: Terminal },
    { label: "Audit Ledger", href: "/ledger", icon: FileText },
    { label: "Lab", href: "/lab", icon: Sliders },
    { label: "Architectures", href: "/architectures", icon: Compass },
    { label: "Integration", href: "/how-it-works", icon: Terminal },
    { label: "Docs", href: "/docs", icon: BookOpen },
    { label: "FAQ", href: "/faq", icon: HelpCircle },
  ];

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-40 transition-all duration-300 select-none",
        isScrolled
          ? "py-2.5 bg-background/85 backdrop-blur-md border-b border-border shadow-md dark:shadow-black/50"
          : "py-4 bg-transparent border-b border-transparent"
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Logo size="md" glow={true} />
          <span className="hidden sm:inline-block px-2 py-0.5 text-[9px] font-mono font-bold tracking-wider rounded border border-warning/40 text-warning bg-warning/10 uppercase">
            PRO COMMAND BUS
          </span>
        </div>

        <nav className="hidden md:flex items-center gap-1 font-mono text-xs font-medium">
          {navLinks.map((link) => {
            const isActive = pathname === link.href;
            return (
              <Link
                key={link.label}
                href={link.href}
                className={cn(
                  "px-3.5 py-1.5 rounded transition-all duration-150 uppercase tracking-wider",
                  isActive
                    ? "text-warning bg-warning/10 font-semibold"
                    : "text-text-secondary hover:text-slate-900 dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/[0.03]"
                )}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden md:flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded border border-warning/40 bg-warning/10 text-warning font-mono text-[10px] font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-warning animate-pulse" />
            <span>COMMAND BUS ARMED</span>
          </div>
        </div>

        <div className="flex md:hidden items-center gap-2">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
            className="p-2 rounded bg-surface border border-border text-text-secondary hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {isMobileMenuOpen && (
        <div className="md:hidden bg-background/95 backdrop-blur-xl border-b border-border px-4 py-4 space-y-2 font-mono text-xs">
          {navLinks.map((link) => {
            const isActive = pathname === link.href;
            return (
              <Link
                key={link.label}
                href={link.href}
                className={cn(
                  "block px-3 py-2 rounded uppercase font-medium",
                  isActive ? "text-warning bg-warning/10" : "text-text-secondary"
                )}
              >
                {link.label}
              </Link>
            );
          })}
        </div>
      )}
    </header>
  );
};
