"use client";

import React from "react";
import Link from "next/link";
import { Logo, StratDeskSymbol } from "@/components/ui/Logo";

export const Footer: React.FC = () => {
  return (
    <footer className="w-full border-t border-border bg-background pt-12 pb-8 select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          <div className="space-y-4 md:col-span-2">
            <Logo size="md" />
            <p className="text-xs text-text-secondary font-sans leading-relaxed max-w-sm">
              StratDesk Pro: Self-hosted institutional command center and bidirectional trading terminal. Includes HMAC-signed emergency kill switches, strategy pauses, and forensic audit trade ledger.
            </p>
            <div className="flex items-center gap-2 text-[10px] font-mono text-warning">
              <span className="w-2 h-2 rounded-full bg-warning animate-pulse" />
              <span>PERPETUAL LICENSE // PRO COMMAND EDITION</span>
            </div>
          </div>

          <div className="flex flex-col gap-2.5 font-mono text-xs">
            <span className="font-bold text-white uppercase tracking-widest text-[11px] mb-1">Navigation</span>
            <Link href="/" className="text-text-secondary hover:text-accent transition-colors">Command Center HUD</Link>
            <Link href="/ledger" className="text-text-secondary hover:text-accent transition-colors">Audit Trade Ledger</Link>
            <Link href="/lab" className="text-text-secondary hover:text-accent transition-colors">Dashboard Lab</Link>
            <Link href="/architectures" className="text-text-secondary hover:text-accent transition-colors">20 Architectures</Link>
          </div>

          <div className="flex flex-col gap-2.5 font-mono text-xs">
            <span className="font-bold text-white uppercase tracking-widest text-[11px] mb-1">Developer & Support</span>
            <Link href="/docs" className="text-text-secondary hover:text-accent transition-colors">Developer Specs</Link>
            <Link href="/how-it-works" className="text-text-secondary hover:text-accent transition-colors">Command Bus Protocol</Link>
            <Link href="/faq" className="text-text-secondary hover:text-accent transition-colors">Technical FAQ</Link>
            <a href="mailto:stratdesk.pro@gmail.com" className="text-text-secondary hover:text-accent transition-colors">stratdesk.pro@gmail.com</a>
          </div>
        </div>

        <div className="pt-6 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-4 font-mono text-xs text-text-muted">
          <div>© {new Date().getFullYear()} StratDesk. All rights reserved. Self-hosted client software.</div>
          <div className="flex items-center gap-2">
            <StratDeskSymbol size={14} />
            <span>STRATDESK PRO // V1.0.0</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
