"use client";

import React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/Button";
import { StratDeskSymbol } from "@/components/ui/Logo";
import { TradingGrid } from "@/components/effects/TradingGrid";
import { GlowField } from "@/components/effects/GlowField";
import { AlertTriangle, Home, BookOpen } from "lucide-react";

export default function NotFound() {
  return (
    <div className="relative min-h-[85vh] flex flex-col items-center justify-center px-4 sm:px-6 lg:px-8 py-24 overflow-hidden bg-background select-none font-mono">
      <TradingGrid dense={true} fadeEdges={true} />
      <GlowField color="amber" position="center" />

      <div className="relative z-10 max-w-xl w-full mx-auto text-center space-y-6">
        <div className="flex justify-center mb-2">
          <div className="relative">
            <StratDeskSymbol size={48} glow={true} />
            <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-red-500/20 border border-red-500/50 flex items-center justify-center text-red-400">
              <AlertTriangle className="w-3 h-3 text-red-500 animate-pulse" />
            </div>
          </div>
        </div>

        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-red-500/30 bg-red-500/10 text-red-400 text-xs font-bold tracking-wider uppercase">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
          <span>404 // ROUTE NOT FOUND</span>
        </div>

        <div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-sans tracking-tight">
            ENDPOINT UNREACHABLE
          </h1>
          <p className="mt-2 text-xs sm:text-sm text-text-secondary font-sans max-w-md mx-auto">
            The requested route does not exist in this self-hosted StratDesk Pro workstation.
          </p>
        </div>

        <div className="pt-2 flex items-center justify-center gap-3">
          <Button href="/" variant="primary" size="md" icon={<Home className="w-4 h-4" />}>
            COMMAND CENTER
          </Button>
          <Button href="/ledger" variant="outline" size="md" icon={<BookOpen className="w-4 h-4" />}>
            TRADE LEDGER
          </Button>
        </div>
      </div>
    </div>
  );
}
