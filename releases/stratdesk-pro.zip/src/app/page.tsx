import React from "react";
import { Metadata } from "next";
import { DashboardPreview } from "@/components/dashboard/DashboardPreview";

export const metadata: Metadata = {
  title: "StratDesk Pro // Institutional Command Center",
  description: "Bidirectional trading command bus, emergency kill-switch, runtime pauses, and forensic audit trade ledger.",
};

export default function ProDashboardPage() {
  return (
    <div className="pt-20 pb-16 px-3 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
      <DashboardPreview
        product="pro"
        theme="obsidian"
        showArchitectureSwitcher={true}
        showThemeSwitcher={true}
      />
    </div>
  );
}
