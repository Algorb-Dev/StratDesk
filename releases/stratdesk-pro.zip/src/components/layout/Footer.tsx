"use client";

import React from "react";
import { Logo } from "@/components/ui/Logo";

export const Footer: React.FC = () => {
  return (
    <footer className="w-full border-t border-border/40 bg-[#07090e] py-6 select-none font-mono text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-text-muted">
        <div className="flex items-center gap-3">
          <Logo size="sm" showWordmark={true} href="/" />
          <span className="text-text-secondary text-[11px]">
            // Institutional Trading Command Center (Self-Hosted)
          </span>
        </div>
        <div className="flex flex-wrap items-center gap-3 text-[10px] text-text-muted">
          <span className="flex items-center gap-1.5 text-emerald-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            LOCAL LOOPBACK IPC &lt; 1ms
          </span>
          <span>•</span>
          <span>HMAC-SHA256 COMMAND BUS</span>
          <span>•</span>
          <a href="mailto:stratdesk.pro@gmail.com" className="hover:text-accent transition-colors">
            stratdesk.pro@gmail.com
          </a>
        </div>
      </div>
    </footer>
  );
};
